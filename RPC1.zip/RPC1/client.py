import rpyc

print("Connecting to RPC server on port 18812...")

try:
    # الاتصال بالسيرفر
    conn = rpyc.connect("localhost", 18812)

    # الوصول للفنكشنات المعرّضة (exposed)
    remote = conn.root

    print("Connection established ✅\n")

    # 1️⃣ Addition
    result_add = remote.exposed_add_numbers(5, 3)
    print("Addition Result:", result_add)

    # 2️⃣ Subtraction
    result_sub = remote.exposed_subtract_numbers(10, 4)
    print("Subtraction Result:", result_sub)

    # 3️⃣ Reverse text
    reversed_text = remote.exposed_reverse_text("hello")
    print("Reversed Text:", reversed_text)

    # 4️⃣ Get system info (dictionary)
    system_info = remote.exposed_get_system_info()
    print("System Info:", system_info)

    # 5️⃣ Send list and sort it
    numbers = [5, 2, 9, 1, 3]
    sorted_numbers = remote.exposed_sort_list(numbers)
    print("Sorted Numbers:", sorted_numbers)

except Exception as e:
    print("RPC Error ❌:", e)

finally:
    try:
        conn.close()
        print("\nCinnection closed.")
    except:
        pass
    