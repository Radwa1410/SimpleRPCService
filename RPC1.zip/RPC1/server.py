# calling RPC library 
#threadedserver to serve more than 1 client
import rpyc 
from rpyc.utils.server import ThreadedServer 

# Define a simple service 
class MyService(rpyc.Service):

    def exposed_add_numbers(self, a, b):
        return a + b

    def exposed_subtract_numbers(self, x, y):
        return x - y

    def exposed_reverse_text(self, text):
        return text[::-1]

    def exposed_get_system_info(self):
        import platform
        return {
            "system": platform.system(),
            "version": platform.version()
        }

    def exposed_sort_list(self, numbers):
        return sorted(numbers)

 
 
if __name__ == "__main__":   
    print("Starting RPC server on port 18812...") 
    server = ThreadedServer(MyService, port=18812) 
    server.start()
